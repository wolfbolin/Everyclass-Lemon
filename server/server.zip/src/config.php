<?php
/**
 * Created by PhpStorm.
 * User: wolfbolin
 * Date: 2019/3/3
 * Time: 0:24
 */
//Configuration
return [
    'Sentry_DSN' => 'https://c9c25e4b58024ac68266c004cafd582a:20d95212f5974fe0b7c45dc1f3482393@sentry.tinoy.xyz/8',
    'Auth_Token' => 'm83EvVsy=68,ZVmy',
    'MongoDB' => [
        'db' => 'everyclass_lemon',
        'host' => '192.168.80.83',  // 192.168.40.129  192.168.80.83
        'port' => '12817',
        'username' => '',
        'password' => '',
        'authSource' => ''
    ],
    'Data' => [
        'mission' => [
            'method' => '',
            'host' => '',
            'path' => '',
            'header' => [],
            'param' => [],
            'data' => '',
            'target' => 0,
            'download' => 0,
            'upload' => 0,
            'success' => 0,
            'error' => 0
        ],
        'cookie' => [
            'cookie' => '',
            'time' => 0,
            'download' => 0,
            'upload' => 0,
            'success' => 0,
            'error' => 0
        ],
        'task' => [
            'status' => '',
            'cid' => '',
            'mid' => '',
            'code' => 0,
            'data' => '',
            'time' => 0,
            'user' => ''
        ]
    ],
    'Statistic' => [
        'status_list' => [
            'total_download' => '',
            'stage_download' => '',
            'total_upload' => '',
            'stage_upload' => '',
            'total_success' => '',
            'stage_success' => '',
            'total_error' => '',
            'stage_error' => '',
            'total_user' => '',
            'stage_user' => ''
        ],
        'stage_list' => [
            'stage_download',
            'stage_upload',
            'stage_success',
            'stage_error',
            'stage_user',
        ],
        'task_list' => [
            'total_upload',
            'stage_upload'
        ],
        'check' => [
            'mongodb' => false
        ]
    ]
];

